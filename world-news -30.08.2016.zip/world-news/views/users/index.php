<?php $this->title='Users'; ?>

<h1><?=htmlspecialchars($this->title) ?></h1>

<table>
    <tr>
        <th>ID</th>
        <th>Username</th>
        <th>Full Name</th>
    </tr>
    <?php foreach ($this->users as $user) : ?>
        <tr>
            <td><?=$user['id'] ?></td>
            <td><?=htmlspecialchars($user['username']) ?></td>
            <td><?=htmlspecialchars($user['full_name']) ?></td>
        </tr>
    <?php endforeach ?>
</table>





<?php
if($_POST){
//get the url
    $url = $_POST['url'];

//add time to the current filename
    $name = basename($url);
    list($txt, $ext) = explode(".", $name);
    $name = $txt.time();
    $name = $name.".".$ext;

//check if the files are only image / document
    if($ext == "jpg" or $ext == "png" or $ext == "gif" or $ext == "doc" or $ext == "docx" or $ext == "pdf"){
//here is the actual code to get the file from the url and save it to the uploads folder
//get the file from the url using file_get_contents and put it into the folder using file_put_contents
        $upload = file_put_contents("$name",file_get_contents($url));
//check success
        if($upload)  echo "Успешно ъплоудване! <a href=".$name." target='_blank'>Проверка на изображенияето</a><br>"; else "please check your folder permission";
    }else{
        echo "Моля, ъплоудвайте само image/document файлове";
    }
}
?>

<html>
<body>
<p></p>
<div>Моля, поставете url-а и натиснете 'Изпрати'!</div>
<form method="post">
    <div>URL:</div>
    <input type="text" name="url"/>
    <div><input type="submit" value="Изпрати"/>
</form>
</body>
</html>

