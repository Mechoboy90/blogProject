<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="<?=APP_ROOT?>/content/styles.css" />
    <link rel="icon" href="<?=APP_ROOT?>/content/images/oreh.png" />
    <script src="<?=APP_ROOT?>/content/scripts/jquery-3.0.0.min.js"></script>
    <script src="<?=APP_ROOT?>/content/scripts/blog-scripts.js"></script>
    <title><?php if (isset($this->title)) echo htmlspecialchars($this->title) ?></title>

<!--// Четем ads от /contents/image_1 и ги изобразяваме на блога отгоре.-->
<!--// Правим така, че като цъкнем на кое да е ads да ни отвори вестник-->
    <?php
    $folder_path = 'content/images_1/'; //image's folder path
    $num_files = glob($folder_path . "*.{JPG,jpg,gif,png,bmp}", GLOB_BRACE);
    $folder = opendir($folder_path);

    if($num_files > 0)
    {
        while(false !== ($file = readdir($folder)))
        {
            $file_path = $folder_path.$file;
            $extension = strtolower(pathinfo($file ,PATHINFO_EXTENSION));
            if($extension=='jpg' || $extension =='png' || $extension == 'gif' || $extension == 'bmp')
            {
                ?>
<!--                <a href="--><?php //echo $file_path; ?><!--"><img src="--><?php //echo $file_path; ?><!--"  height="100" /></a>-->
                <a href= "http://www.standartnews.com"><img src="<?php echo $file_path; ?>"  height="50" /></a>
                <?php
            }
        }
    }
    ?>
    <!--    <a href="http://www.standartnews.com"><img src="--><?//=APP_ROOT?><!--/content/images/oreh.jpg" height="100" /></a>-->
<!--//Край-->

</head>

<body>
<header>
    <a href="<?=APP_ROOT?>"><img src="<?=APP_ROOT?>/content/images/world-news-logo.png"></a>
    <a href="<?=APP_ROOT?>/">Home</a>
    <?php if ($this->isLoggedIn) : ?>
        <a href="<?=APP_ROOT?>/posts">Posts</a>
        <a href="<?=APP_ROOT?>/posts/create">Create Post</a>
        <a href="<?=APP_ROOT?>/users">Users</a>
    <?php else: ?>
        <a href="<?=APP_ROOT?>/users/login">Login</a>
        <a href="<?=APP_ROOT?>/users/register">Register</a>
    <?php endif; ?>
    <?php if ($this->isLoggedIn) : ?>
        <div id="logged-in-info">
            <span>Hello, <b><?=htmlspecialchars($_SESSION['username'])?></b></span>
            <form method="post" action="<?=APP_ROOT?>/users/logout">
                <input type="submit" value="Logout"/>
            </form>

<!--//Ъплоудваме картинка от сайт (url) и я записваме в /content/image_1-->
            <?php
            if($_POST){
              //get the url
                $url = $_POST['url'];
              //add time to the current filename
                $name = basename($url);
                list($txt, $ext) = explode(".", $name);
                $name = $txt.time();
                $name = $name.".".$ext;

              //check if the files are only image / document
                if($ext == "jpg" or $ext == "png" or $ext == "gif" or $ext == "doc" or $ext == "docx" or $ext == "pdf"){
              //here is the actual code to get the file from the url and save it to the uploads folder
              //get the file from the url using file_get_contents and put it into the folder using file_put_contents
                    $upload = file_put_contents("c:/xampp/htdocs/world-news/content/images_1/$name",file_get_contents($url));
              //check success
                    if($upload)  echo "Успешно ъплоудване! <a href='/world-news/content/images_1/".$name."' target='_blank'>Проверка на изображенияето</a><br>"; else "please check your folder permission";
                }else{
                    echo "Моля, ъплоудвайте само image/document файлове";
                }
            }
            ?>

            <p></p>
            <div>За вкарване на рекламки поставете</div>
            <div>url-а и натиснете 'Изпрати'!</div>
            <form method="post">
                <div>
                    URL: <input type="text" name="url"/>
                         <input type="submit" value="Изпрати"/>
                </div>
            </form>
<!--//Край на ъплоудвънето-->

        </div>
    <?php endif; ?>
</header>

<?php require_once('show-notify-messages.php'); ?>
