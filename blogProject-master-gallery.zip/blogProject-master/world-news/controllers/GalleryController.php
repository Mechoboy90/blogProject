<?php
class GalleryController extends BaseController
{
    function gallery() {
        echo "wdwsdwddedew";
    }
}